import java.util.Scanner;

public class Actividad2 {
    public static void main(String[] args) {
try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Ingrese usuario: ");
            String usuario = scanner.nextLine(); // Corregido nextLine()
            switch (usuario) {
                case "Manuel" -> System.out.println("Bienvenido Andres Manuel De la Pinta Maria Tercero Herrera Hernandez Lopez");
                case "manuel" -> System.out.println("Maldito farsante, Andres Manuel De la Pinta Maria Tercero Herrera Hernandez Lopez, nunca escribiria su nombre sin mayúscula");
                default -> System.out.println("WHO?");
            }
            // Corregido close()
                    }
                    
    }
}

